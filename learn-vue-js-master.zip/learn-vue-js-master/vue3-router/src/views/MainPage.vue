<template>
  <div>
    main
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss" scoped>

</style>